import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:bluezone_cidadao/HomePage.dart';
import 'package:bluezone_cidadao/Ticket.dart';
import 'package:clipboard/clipboard.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:qr/qr.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'api/notifications_api.dart';

class PagamentoPIX extends StatefulWidget {

  String placa;
  String cpf;
  String estadia;
  String pagamento;
  PagamentoPIX(this.placa, this.cpf, this.estadia, this.pagamento);

  @override
  State<PagamentoPIX> createState() => _PagamentoPIXState();
}

class _PagamentoPIXState extends State<PagamentoPIX> {

  void listenNotifications() =>{
    NotificationAPI.onNotifications.stream.listen(onClickedNotification1),
    NotificationAPI1.onNotifications1.stream.listen(onClickedNotification)
  };

  void onClickedNotification1(String? payload) =>{
  };

  void onClickedNotification(String? payload) =>{
    Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => Home())),
  };

  static const timeout = const Duration(seconds: 10);
  static const ms = const Duration(milliseconds: 1);

  _startTimeout([int? milliseconds]) {
    var duration = milliseconds == null ? timeout : ms * milliseconds;
    return Timer(duration, handleTimeout);
  }

  void handleTimeout() {
    _salvarPagamento();
  }


  _salvarPagamento()async{
    String valor;
    String horario;
    String meucpf;
    String datahora;
    String minhaplaca;

    valor = widget.pagamento;
    horario = widget.estadia;
    meucpf = widget.cpf;
    datahora = DateTime.now().toLocal().toString();
    minhaplaca = widget.placa;

    var _random = Random.secure();
    var random = List<int>.generate(32, (i) => _random.nextInt(256));
    var verificador = base64Url.encode(random);

    FirebaseFirestore db = FirebaseFirestore.instance;
    DocumentReference ref = await
    db.collection("Veículo")
        .add(
        {
          "CPF" : widget.cpf,
          "Placa" : widget.placa.toUpperCase(),
          "Estadia(h)" : widget.estadia,
          "Token" : verificador,
          "Pagamento" : 1,
          "Dia/Hora" : DateTime.now().toLocal().toString()
        }
    );
    void updatePag(){
      FirebaseFirestore.instance
          .collection("Veículo")
          .doc(ref.id)
          .update({
        "Pagamento" : 0
      }).then((result){
        print("Alterado");
      }).catchError((onError){
        print("Não Alterado");
      });
    }

    void update(){
      const timeoutt = const Duration(seconds: 15);
      const mss = const Duration(milliseconds: 1);

      void handleTimeout() {
        NotificationAPI.showNotification(
          title: 'BlueZone - Sua Estadia',
          body: 'Sua estadia acabou.',
          payload: 'Estadia',
        );
        updatePag();
      }

      _startTimeoutt([int? milliseconds]) {
        var duration = milliseconds == null ? timeoutt : mss * milliseconds;
        return Timer(duration, handleTimeout);
      }

      _startTimeoutt();
    }

    const timeout = const Duration(seconds: 8);
    const ms = const Duration(milliseconds: 1);

    void handleTimeoutt() {
      NotificationAPI1.showNotification(
        title: 'BlueZone - Sua Estadia',
        body: 'Faltam 5 minutos para acabar sua estadia.',
        payload: 'Estadia',
      );
      update();
    }

    _startTimeout([int? milliseconds]) {
      var duration = milliseconds == null ? timeout : ms * milliseconds;
      return Timer(duration, handleTimeoutt);
    }

    if(horario == '1 Hora'){
      NotificationAPI.showNotification(
        title: 'BlueZone - Sua Estadia',
        body: 'Você possue: ${widget.estadia}',
        payload: 'Estadia',
      );
      _startTimeout();
    }else if(horario == '2 Horas'){
      NotificationAPI.showNotification(
        title: 'BlueZone - Sua Estadia',
        body: 'Você possue: ${widget.estadia}',
        payload: 'Estadia',
      );
      _startTimeout();
    }else if(horario == '3 Horas'){
      NotificationAPI.showNotification(
        title: 'BlueZone - Sua Estadia',
        body: 'Você possue: ${widget.estadia}',
        payload: 'Estadia',
      );
      _startTimeout();
    }else if(horario == '4 Horas'){
      NotificationAPI.showNotification(
        title: 'BlueZone - Sua Estadia',
        body: 'Você possue: ${widget.estadia}',
        payload: 'Estadia',
      );
      _startTimeout();
    }
    print("salvou");
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => TicketWidget(valor, horario, meucpf, datahora, minhaplaca)
        )
    );
  }

  var rng = new Random();
  var minhachave = 'de7530ee-Bluec61ab0Zone';
  var chavePIX = 'de7530ee-Bluec61a8b0Zone';

  @override
  void initState() {
    super.initState();
    NotificationAPI.init();
    listenNotifications();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 60),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children:  <Widget>[
                  Container(
                    width: 140,
                    height: 35,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(width: 1, color: Colors.green)
                    ),
                    child: Center(
                      child: Text(
                        'Valor: R\$${widget.pagamento}',
                        style: TextStyle(
                            color: Colors.green,
                          fontSize: 19,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 40),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.only(right: 30),
                          child: Row(
                            children: <Widget>[
                              Text(
                                'Placa:${widget.placa}',
                                style: TextStyle(
                                    color: Colors.black,
                                  fontSize: 18,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 30),
                          child: Row(
                            children: <Widget>[
                              Text(
                                'Estadia:${widget.estadia}',
                                style: TextStyle(
                                    color: Colors.black,
                                  fontSize: 18,
                                ),
                              ),
                            ],
                          ),
                        )
                      ]
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 40),
                  ),
                  QrImage(
                    gapless: true,
                    data: "BlueZone",
                    size: 250,
                    errorCorrectionLevel: QrErrorCorrectLevel.H,
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 40),
                    child: Text(
                      "PIX Copia e Cola",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold
                      ),
                    )
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 10),
                    child: Container(
                      width: 280,
                      height: 35,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(width: 1, color: Colors.green)
                      ),
                        child: Row(
                          children: [
                            Text(
                              '${chavePIX}',
                              style: TextStyle(
                                color: Colors.green,
                                fontSize: 16,
                              ),
                            ),
                            IconButton(
                              alignment: Alignment.centerRight,
                              icon: Image.asset('imagens/copiar-conteudo.png'),
                              iconSize: 50,
                              onPressed: () {
                                FlutterClipboard.controlC(chavePIX);
                                _salvarPagamento();
                              },
                            ),
                          ]
                        ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}