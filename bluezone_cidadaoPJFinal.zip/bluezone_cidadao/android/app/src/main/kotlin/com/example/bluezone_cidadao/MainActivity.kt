package com.example.bluezone_cidadao

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
